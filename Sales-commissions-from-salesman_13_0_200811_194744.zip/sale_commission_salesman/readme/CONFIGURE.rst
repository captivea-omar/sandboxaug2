#. Go to *Contacts*.
#. Search for the contact linked to the salesman user and open it.
#. If it's actually linked to a user, you'll see a new check in the
   *Agent information* page, called "Convert salesman into agent".
#. Check it for having that salesman automatically populated as agent. You
   need to assign a commission to that agent as well.
