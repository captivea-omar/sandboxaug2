# Not ordering this list, the order of creation is important
from . import sale_commission
from . import sale_commission_mixin
from . import account_move
from . import product_template
from . import res_partner
from . import sale_order
from . import settlement
