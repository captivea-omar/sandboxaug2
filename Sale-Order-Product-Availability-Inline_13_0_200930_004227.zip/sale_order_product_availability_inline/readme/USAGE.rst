To use this module, you need to:

#. Go to *Sales > Order > Orders* and add a new sales order or create a new one
#. Add a new order line and click on the product field to see the
   available products to select.
#. You will see the stock availability (Free To Use Quantity) of each
   product as part of its name.
