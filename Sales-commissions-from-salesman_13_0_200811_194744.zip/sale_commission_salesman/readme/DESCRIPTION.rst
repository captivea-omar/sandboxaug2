This module extends the functionality of `sale_commission` to allow you to
auto-populate salesmen as commission agents without setting explicitly them
on the customer.

**IMPORTANT**: The salesman will be only populated if no other commission agent
is set via other method, to assure that there's no overlapping commissions.
