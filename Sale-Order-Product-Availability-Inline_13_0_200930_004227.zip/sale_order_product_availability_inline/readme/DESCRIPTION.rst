This module extends the functionality of 'Sales and Warehouse Management'
to show you the stock availability (Free To Use Quantity) of each product
as part of its name in the product drop-down widget on sales order lines.
