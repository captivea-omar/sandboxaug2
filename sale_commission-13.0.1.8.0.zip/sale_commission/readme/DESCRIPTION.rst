This module allows to define sales agents with their commissions and assign
them in customers and sales orders.

You can then make the settlements of these commissions, and generate the
corresponding supplier invoices to pay their commissions fees.

You can define which base amount is going to be taken into account: net amount
(based on margin) or gross amount (line subtotal amount)
