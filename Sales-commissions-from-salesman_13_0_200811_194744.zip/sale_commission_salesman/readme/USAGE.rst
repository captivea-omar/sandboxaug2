To use this module, you need to:

#. Go to *Sales > Orders > Quotations* and create a new one.
#. Fill the customer with one with no agents set.
#. Select a salesman with the mark checked.
#. Add a line in the quotation, and you will see the salesman populated as
   commission agent.
