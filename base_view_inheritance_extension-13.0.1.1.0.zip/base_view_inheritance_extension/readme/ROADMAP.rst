* add ``<attribute operation="json_dict" key="$key">$value</attribute>``
* support ``<xpath expr="$xpath" position="move" target="xpath" target_position="position" />``
* support an ``eval`` attribute for our new node types
